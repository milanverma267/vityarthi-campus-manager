# VITyarthi — Campus Event & Resource Manager

Centralized web platform for creating, managing and discovering campus events; booking resources (rooms, projectors, labs); RSVP & QR-based attendance; and analytics for organizers.

## Repo
GitHub user: **milanverma2005**  
Suggested repo name: **vityarthi-campus-manager**

## Contents
- backend/ — Node.js + Express API scaffold
- frontend/ — React + Vite minimal scaffold
- docs/ — project report and diagrams
- README.md, statement.md, LICENSE, .gitignore

## Quickstart (local)

### Start backend:
```
cd backend
npm install
cp .env.example .env
npm run dev
```

### Start frontend:
```
cd frontend
npm install
npm run dev
```

## GitHub push:
```
git init
git add .
git commit -m "Initial scaffold: VITyarthi"
git branch -M main
git remote add origin https://github.com/milanverma2005/vityarthi-campus-manager.git
git push -u origin main
```

## Project Report
Stored at: `docs/project_report.pdf`
